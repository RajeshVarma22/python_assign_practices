income_input = float(input("Enter your income: "))
marital_status = input("Enter your marital status either married/single: ").lower()
tax_less = 10
tax_higher = 25


if (marital_status == "single"):
    if(income_input <= 32000):
        percen_tax = income_input*(tax_less/100)
        print(percen_tax)
    else:
        percen_tax_high = income_input*(tax_higher / 100)
        print(percen_tax_high)
elif (marital_status == "married"):
    if(income_input <= 64000):
        percen_tax = income_input*(tax_less/100)
        print(percen_tax)
    else:
        percen_tax_high = income_input*(tax_higher / 100)
        print(percen_tax_high)
else:
    print("Please enter marital ststus as married/single")