investment = float(input("Enter investment amount: "))
interest = float(input("Enter anuual interest percentage: "))
years = 0
current_amount = 0

while(current_amount < investment):
    interest_gained_year = investment * (interest / 100)
    current_amount += interest_gained_year
    years += 1

print("The number of years taken to double the investment is {} Years".format(years))
